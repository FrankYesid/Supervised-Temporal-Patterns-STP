How to use the GFS program:

The program should run in a DOS window under Windows. A Windows Version is planned, 
but not yet available.



1. How to prepare the input  data file:

Input EEG files are plain ASCII text files, which can be produced by most EEG systems. 
The data must be in the time domain (not frequency transformed).

The format should look like this:

Ch1/T1 Ch2/T1 Ch3/T1 ......
Ch1/T2 Ch2/T2 Ch3/T2 .....
Ch1/T3 ........

where Ch1/T1 is the voltage at channel 1 at time instance 1.

The data must not contain auxiliary channels like EKG or EOG. The reference electrode is not important.
Each file should contain a continuous, artefact free epoch, and there can be many files per subject. 
If possible, avoid offline filtering before you export the data.

For each subject, you also need a single text file containing the name of all ASCII EEG files of one subject.

2. How to specify the frequency bands:

There is a sample file with frequency band definitions which you can use as template. The first number 
in the first line indicates the number of frequency bands defined. 


How to run the program:

The program will both run in an interactive and non-interactive mode: If you give all the necessary 
information as parameters on the command line (i.e. in a batch file), the computation is started 
immediately, if you don't, the program will ask for it. 


Here are some complete sample command line

GFS sub1.lst gfs.out mybands.txt 256 19 128 control 18.5
GFS sub2.lst gfs.out mybands.txt 256 19 128 patient 23.1

- sub1.lst is the input file list as described in point 1.

- gfs.out is a tab-delimited text output file. If the file does not esist, it will be created.
  If it exists, a new line will appended at the end of the file. Thus, if you always specify
  the same output file throughout your analysis, you can directly obtain a single file with 
  the data of all subjects, which is covenient for later statistics. However, if you want to 
  redo the analysis, be sure to rename/delete the old output file, or the two analyses might 
  mix up.

- mybands.txt is a sample frequency band definition.

- 256 is the number of time points in the ASCII EEG files 
- 19 is the number of electrodes in the ASCII EEG files
- 128 is the number of samples per second in the ASCII EEG files

- There are additional, optional parameters (in our case a group assignment and an age): These will be copied 
  into your output file. This is therefore a convenient way to put your independent variables into your
  output file.

If you have any further questions, please let me know. I'll be happy to help.


Thomas Koenig


thomas.koenig@puk.unibe.ch

